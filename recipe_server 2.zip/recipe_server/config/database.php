<?php
// database config
$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "recipe_blog";

// create database connection
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn -> connect_error){
  die("connection failed: " . $con -> connect_error);
}
?>