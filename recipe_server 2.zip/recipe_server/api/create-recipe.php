<?php
header("Access-Control-Allow-Origin: *"); // Allow requests from any origin, or specify your frontend URL
header("Access-Control-Allow-Headers: Content-Type, POST, OPTIONS");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);

if (empty($data['title']) || empty($data['recipe']) || empty($data['name'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Error: Missing or empty required parameter']);
    exit();
}

$title = filter_var($data['title'], FILTER_SANITIZE_STRING);
$recipe = filter_var($data['recipe'], FILTER_SANITIZE_STRING);
$name = filter_var($data['name'], FILTER_SANITIZE_STRING);


$stmt = $conn->prepare('INSERT INTO recipe_posts (title, recipe, name) VALUES (?, ?, ?)');
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['message' => 'Database error: ' . $conn->error]);
    exit();
}

$stmt->bind_param('sss', $title, $recipe, $name);

if ($stmt->execute()) {
    $id = $stmt->insert_id;
    http_response_code(201);
    echo json_encode(['message' => 'Post created successfully', 'id' => $id]);
} else {
    http_response_code(500);
    echo json_encode(['message' => 'Error creating post: ' . $stmt->error]);
}

$stmt->close();
$conn->close();

?>
