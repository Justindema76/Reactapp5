<?php
header("Access-Control-Allow-Origin: *"); // Allow requests from any origin, or specify your frontend URL
header("Access-Control-Allow-Headers: Content-Type, POST, OPTIONS");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

// Handle preflight request (OPTIONS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get the raw POST body data
$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);

// Validate required fields
if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Error: Missing or empty required parameter']);
    exit();
}

// Sanitize the inputs
$username = filter_var($data['username'], FILTER_SANITIZE_STRING);
$email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
$password = filter_var($data['password'], FILTER_SANITIZE_STRING);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['message' => 'Error: Invalid email format']);
    exit();
}

// Hash the password before saving it
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Prepare SQL query to insert new user into the database
$stmt = $conn->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['message' => 'Database error: ' . $conn->error]);
    exit();
}

// Bind parameters for the query
$stmt->bind_param('sss', $username, $email, $hashedPassword);

// Execute the statement
if ($stmt->execute()) {
    $id = $stmt->insert_id; // Get the id of the newly inserted user
    http_response_code(201); // Success response
    echo json_encode(['message' => 'User registered successfully', 'id' => $id]);
} else {
    http_response_code(500); // Database insertion error
    echo json_encode(['message' => 'Error registering user: ' . $stmt->error]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
