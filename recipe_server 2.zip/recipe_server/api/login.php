<?php
header("Access-Control-Allow-Origin: *"); // Allow requests from any origin, or specify your frontend URL
header("Access-Control-Allow-Headers: Content-Type, POST, OPTIONS");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

// Handle preflight request (OPTIONS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get the raw POST body data
$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);

// Validate required fields
if (empty($data['email']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Error: Missing or empty required parameter']);
    exit();
}

// Sanitize inputs
$email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
$password = filter_var($data['password'], FILTER_SANITIZE_STRING);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['message' => 'Error: Invalid email format']);
    exit();
}

// Check if the user exists in the database
$stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(401);
    echo json_encode(['message' => 'Error: Invalid email or password']);
    exit();
}

// Fetch user data
$user = $result->fetch_assoc();

// Verify the password
if (password_verify($password, $user['password'])) {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Login successful!', 'user' => $user]);
} else {
    http_response_code(401);
    echo json_encode(['message' => 'Error: Invalid email or password']);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
